<?php

\Magento\Framework\Component\ComponentRegistrar::register(
\Magento\Framework\Component\ComponentRegistrar::MODULE, 'TrainingHitakshi_SimpleModule',
__DIR__
);