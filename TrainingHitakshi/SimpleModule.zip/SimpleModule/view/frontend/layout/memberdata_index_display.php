<?xml version="1.0"?>
<page xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" layout="1column" xsi:noNamespaceSchemaLocation="urn:magento:framework:View/Layout/etc/page_configuration.xsd">
    <referenceContainer name="content">
        <block class="TrainingHitakshi\SimpleModule\Block\Display" name="memberdata_display" template="TrainingHitakshi_SimpleModule::memberdata.phtml" />
    </referenceContainer>
</page>